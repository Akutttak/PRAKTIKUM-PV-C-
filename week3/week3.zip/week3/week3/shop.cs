﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week3
{
    public partial class shop : Form
    {
        private User currentUser;
        public int price_oak = 50;
        public int price_mahgony = 120;
        public int price_mystic = 250;
        public shop(User user)
        {
            InitializeComponent();
            currentUser = user;
        }

        private void shop_Load(object sender, EventArgs e)
        {
            UpdateShopDisplay();

            List<string> axeNames = new List<string>();
            foreach (Tool axe in currentUser.AxeInventory)
            {
                axeNames.Add(axe.Nama);
            }
            string ownedAxes = string.Join(", ", axeNames);
            if (string.IsNullOrEmpty(ownedAxes))
                ownedAxes = "Belum punya kapak";

            labelOwn.Text = $"Owned: {ownedAxes}";

            labelEquipped.Text = $"Equipped: {currentUser.ActiveAxe.Nama}";
        }

        private int GetJumlahLog(string namaKayu)
        {
            foreach (var log in currentUser.LogInventory)
            {
                if (log.NamaKayu.Equals(namaKayu, StringComparison.OrdinalIgnoreCase))
                {
                    return log.Jumlah;
                }
            }
            return 0;
        }

        private void buttonSellMystic_Click(object sender, EventArgs e)
        {
            SellLog("mystic", 250);
        }

        private void buttonSellMahgony_Click(object sender, EventArgs e)
        {
            SellLog("mahogany", 120);
        }

        private void buttonSellOak_Click(object sender, EventArgs e)
        {
            SellLog("oak", 50);
        }

        private void SellLog(string namaKayu, int hargaPerLog)
        {
            var log = currentUser.LogInventory
                .FirstOrDefault(x => x.NamaKayu.Equals(namaKayu, StringComparison.OrdinalIgnoreCase));

            if (log == null || log.Jumlah == 0)
            {
                MessageBox.Show($"Kamu tidak punya {namaKayu} log!", "Info");
                return;
            }

            int jumlahJual = 1;
            int totalHarga = jumlahJual * hargaPerLog;
            currentUser.uang += totalHarga;
            log.Jumlah -= jumlahJual;

            MessageBox.Show($"Berhasil menjual {jumlahJual} {namaKayu} log seharga Rp {totalHarga}!", "Berhasil");

            shop_Load(null, null);
        }

        private void BuyAxe(string nama, int harga, string type)
        {
            if (currentUser.uang < harga)
            {
                MessageBox.Show("Uangmu tidak cukup!", "Gagal");
                return;
            }

            if (currentUser.AxeInventory.Any(a => a.Nama.Equals(nama, StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show($"Kamu sudah punya {nama}!", "Info");
                return;
            }

            Tool newAxe = new Tool(nama, harga, type);
            currentUser.AxeInventory.Add(newAxe);
            currentUser.uang -= harga;

            MessageBox.Show($"Kamu membeli {nama} seharga Rp {harga}!", "Berhasil");
            shop_Load(null, null);
        }

        private void buttonBuyIron_Click(object sender, EventArgs e)
        {
            BuyAxe("Iron Axe", 1500, "Iron");
        }

        private void buttonBuyDiamond_Click(object sender, EventArgs e)
        {
            BuyAxe("Diamond Axe", 3000, "Diamond");
        }

        


        private void UpdateShopDisplay()
        {
            labelUang.Text = $"Uang: {currentUser.uang}";
            labelOak.Text = $"Oak: {GetJumlahLog("oak")} (Rp 50/log)";
            labelMahogany.Text = $"Mahogany: {GetJumlahLog("mahogany")} (Rp 120/log)";
            labelMystic.Text = $"Mystic: {GetJumlahLog("mystic")} (Rp 250/log)";

            string ownedAxes = string.Join(", ", currentUser.AxeInventory.Select(a => a.Nama));
            if (string.IsNullOrEmpty(ownedAxes))
                ownedAxes = "Belum punya kapak";

            labelOwn.Text = $"Owned: {ownedAxes}";

            labelEquipped.Text = $"Equipped: {currentUser.ActiveAxe.Nama}";
        }

        private void buttonSellAll_Click(object sender, EventArgs e)
        {
            int totalLogsSold = 0;
            long totalRevenue = 0;

            var logsToSell = new List<LogItem>(currentUser.LogInventory);

            foreach (var log in logsToSell)
            {
                int hargaPerLog = 0;
                if (log.NamaKayu.Equals("oak", StringComparison.OrdinalIgnoreCase)) hargaPerLog = price_oak;
                else if (log.NamaKayu.Equals("mahogany", StringComparison.OrdinalIgnoreCase)) hargaPerLog = price_mahgony;
                else if (log.NamaKayu.Equals("mystic", StringComparison.OrdinalIgnoreCase)) hargaPerLog = price_mystic;

                if (hargaPerLog > 0 && log.Jumlah > 0)
                {
                    long revenue = (long)log.Jumlah * hargaPerLog;
                    totalRevenue += revenue;
                    totalLogsSold += log.Jumlah;

                    currentUser.LogInventory.Remove(log);
                }
            }

            if (totalLogsSold > 0)
            {
                currentUser.uang += totalRevenue;
                MessageBox.Show($"Berhasil menjual {totalLogsSold} total log. Kamu mendapatkan Rp {totalRevenue:N0}!", "Penjualan Massal Berhasil");
            }
            else
            {
                MessageBox.Show("Kamu tidak punya log untuk dijual.", "Info");
            }

            UpdateShopDisplay();
        }
    }
}
