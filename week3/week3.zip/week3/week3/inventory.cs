﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week3
{
    public partial class inventory : Form
    {
        private User currentUser;
        public inventory(User user)
        {
            InitializeComponent();
            currentUser = user;
        }

        private void inventory_Load(object sender, EventArgs e)
        {
            labelUang.Text = $"Uang: {currentUser.uang}";

            labelOak.Text = $"Oak: {GetJumlahLog("oak")}";
            labelMahogany.Text = $"Mahogany: {GetJumlahLog("mahogany")}";
            labelMystic.Text = $"Mystic: {GetJumlahLog("mystic")}";

            UpdateAxeAvailability();
        }
        private int GetJumlahLog(string namaKayu)
        {
            foreach (var log in currentUser.LogInventory)
            {
                if (log.NamaKayu.ToLower() == namaKayu.ToLower())
                {
                    return log.Jumlah;
                }
            }
            return 0;
        }

        private void UpdateAxeAvailability()
        {
            radioButtonStoneAxe.Enabled = false;
            radioButtonIron.Enabled = false;
            radioButtonDiamond.Enabled = false;

            if (currentUser.HasAxe("Stone Axe")) radioButtonStoneAxe.Enabled = true;
            if (currentUser.HasAxe("Iron Axe")) radioButtonIron.Enabled = true;
            if (currentUser.HasAxe("Diamond Axe")) radioButtonDiamond.Enabled = true;

            if (currentUser.ActiveAxe.Nama == "Stone Axe") radioButtonStoneAxe.Checked = true;
            if (currentUser.ActiveAxe.Nama == "Iron Axe") radioButtonIron.Checked = true;
            if (currentUser.ActiveAxe.Nama == "Diamond Axe") radioButtonDiamond.Checked = true;
        }


        private void radioButtonStoneAxe_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonStoneAxe.Checked)
            {
                currentUser.ActiveAxe = new Tool("Stone Axe", 0, "Stone");
                MessageBox.Show("user pilih stone");
            }
        }

        private void radioButtonIron_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonIron.Checked)
            {
                currentUser.ActiveAxe = new Tool("Iron Axe", 1500, "Iron");
                MessageBox.Show("user pilih iron");
            }
        }

        private void radioButtonDiamond_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButtonDiamond.Checked)
            {
                currentUser.ActiveAxe = new Tool("Diamond Axe", 6000, "Diamond");
                MessageBox.Show("user pilih diamond");
            }
        }
    }
}
