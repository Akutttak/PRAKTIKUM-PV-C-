﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace week3
{
    public class User
    {
        public double uang { get; set; }
        public List<LogItem> LogInventory { get; set; }
        public List<Tool> AxeInventory { get; set; } 
        public Tool ActiveAxe { get; set; }

        public User()
        {
            uang = 50000;
            LogInventory = new List<LogItem>();
            AxeInventory = new List<Tool>();

            Tool stoneAxe = new Tool("Stone Axe", 0, "Stone");
            AxeInventory.Add(stoneAxe);
            ActiveAxe = stoneAxe;

        }

        public void TambahLog(string namaKayu, int jumlah)
        {
            var existing = LogInventory.FirstOrDefault(x => x.NamaKayu == namaKayu);
            if (existing != null)
                existing.Jumlah += jumlah;
            else
                LogInventory.Add(new LogItem(namaKayu, jumlah));
        }

        public bool HasAxe(string namaAxe)
        {
            return AxeInventory.Any(a =>
                a.Nama.Equals(namaAxe, StringComparison.OrdinalIgnoreCase));
        }

        public void EquipAxe(string namaAxe)
        {
            var axe = AxeInventory.FirstOrDefault(a =>
                a.Nama.Equals(namaAxe, StringComparison.OrdinalIgnoreCase));
            if (axe != null)
            {
                ActiveAxe = axe;
            }
        }

        public void TambahAxe(Tool tool)
        {
            bool sudahAda = AxeInventory.Any(t =>
                t.Nama.Equals(tool.Nama, StringComparison.OrdinalIgnoreCase));

            if (!sudahAda)
                AxeInventory.Add(tool);
        }

    }
}
